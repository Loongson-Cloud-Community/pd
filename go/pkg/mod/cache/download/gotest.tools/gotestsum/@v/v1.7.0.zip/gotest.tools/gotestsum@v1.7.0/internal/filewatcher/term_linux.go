package filewatcher

import "golang.org/x/sys/unix"

const tcGet = unix.TCGETS
const tcSet = unix.TCSETS
