// +build stubpkg

package empty
