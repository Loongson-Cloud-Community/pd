// Package data contains binary and external asset files for Appdash.
package data

//go:generate go run generate.go
