// Package flagext implements extensions to the standard flag package in the form of types that implement flag.Value
package flagext
