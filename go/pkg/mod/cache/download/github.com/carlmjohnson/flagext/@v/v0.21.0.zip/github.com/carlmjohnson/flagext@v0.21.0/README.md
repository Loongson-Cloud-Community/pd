# flagext [![GoDoc](https://godoc.org/github.com/carlmjohnson/flagext?status.svg)](https://godoc.org/github.com/carlmjohnson/flagext) [![Go Report Card](https://goreportcard.com/badge/github.com/carlmjohnson/flagext)](https://goreportcard.com/report/github.com/carlmjohnson/flagext)

Implementations of the flag.Value interface to extend the flag package
