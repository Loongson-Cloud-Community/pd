#include "osage/osageinit.c"
