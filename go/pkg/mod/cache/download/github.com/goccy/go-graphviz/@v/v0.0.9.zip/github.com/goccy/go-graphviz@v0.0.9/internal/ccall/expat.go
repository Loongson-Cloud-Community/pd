package ccall

/*
#cgo CFLAGS: -I../expat
*/
import "C"
