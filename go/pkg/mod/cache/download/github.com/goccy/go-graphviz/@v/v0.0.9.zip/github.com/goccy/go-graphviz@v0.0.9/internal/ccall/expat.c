#include "expat_config.h"

#include "../expat/xmlparse.c"
#include "../expat/xmltok.c"
#include "../expat/xmlrole.c"
