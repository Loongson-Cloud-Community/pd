// +build sqlite

package main

import (
	_ "github.com/mattn/go-sqlite3"
)
