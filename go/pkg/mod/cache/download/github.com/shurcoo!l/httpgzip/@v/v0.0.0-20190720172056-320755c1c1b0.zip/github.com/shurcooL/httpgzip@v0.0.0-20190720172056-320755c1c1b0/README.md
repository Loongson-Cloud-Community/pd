httpgzip
========

[![Build Status](https://travis-ci.org/shurcooL/httpgzip.svg?branch=master)](https://travis-ci.org/shurcooL/httpgzip) [![GoDoc](https://godoc.org/github.com/shurcooL/httpgzip?status.svg)](https://godoc.org/github.com/shurcooL/httpgzip)

Package httpgzip provides net/http-like primitives
that use gzip compression when serving HTTP requests.

Installation
------------

```bash
go get -u github.com/shurcooL/httpgzip
```

License
-------

-	[MIT License](LICENSE)
