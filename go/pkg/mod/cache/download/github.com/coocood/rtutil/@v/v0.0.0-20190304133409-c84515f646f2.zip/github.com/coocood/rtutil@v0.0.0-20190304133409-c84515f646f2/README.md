# rtutil
Export some useful functions from Go runtime library.
