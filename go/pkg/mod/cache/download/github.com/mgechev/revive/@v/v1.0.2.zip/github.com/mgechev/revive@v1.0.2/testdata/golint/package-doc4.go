// Test of block package comment with leading space.

/*
 Package foo is pretty sweet.
MATCH /package comment should not have leading space/
*/
package foo
