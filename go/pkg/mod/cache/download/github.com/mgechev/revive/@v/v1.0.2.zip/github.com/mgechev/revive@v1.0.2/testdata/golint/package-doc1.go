// Test of missing package comment.

package foo // MATCH /should have a package comment, unless it's in another file for this package/
