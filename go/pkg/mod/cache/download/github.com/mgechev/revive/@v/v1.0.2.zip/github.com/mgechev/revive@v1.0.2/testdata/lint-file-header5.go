// foobaz qux
// bar

package fixtures
