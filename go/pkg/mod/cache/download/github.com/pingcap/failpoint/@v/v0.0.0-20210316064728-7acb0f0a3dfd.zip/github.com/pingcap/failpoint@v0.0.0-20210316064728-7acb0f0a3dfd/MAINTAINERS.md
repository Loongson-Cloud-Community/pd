# Maintainers

This file lists who are the core maintainers of the failpoint project.

## Project Lead

* [Heng Long](https://github.com/lonng)

## Other Core Maintainers

* [Kangli Mao](https://github.com/tiancaiamao)
* [Li Su](https://github.com/lysu)
