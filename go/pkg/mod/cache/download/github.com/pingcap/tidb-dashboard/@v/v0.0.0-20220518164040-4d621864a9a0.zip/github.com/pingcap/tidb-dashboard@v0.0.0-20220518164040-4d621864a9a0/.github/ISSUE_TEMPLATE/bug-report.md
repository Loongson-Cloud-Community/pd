---
name: "\U0001F41B Bug Report"
about: Something isn't working as expected
title: ""
labels: type/bug
assignees: ""
---

## Bug Report

Please answer these questions before submitting your issue. Thanks!

**What did you do?**

<!-- If possible, provide a recipe for reproducing the error.  -->

**What did you expect to see?**

<!-- Please fill. -->

**What did you see instead?**

<!-- Please fill. -->

**What version of TiDB Dashboard are you using (`./tidb-dashboard --version`)?**

<!-- Please fill. -->
