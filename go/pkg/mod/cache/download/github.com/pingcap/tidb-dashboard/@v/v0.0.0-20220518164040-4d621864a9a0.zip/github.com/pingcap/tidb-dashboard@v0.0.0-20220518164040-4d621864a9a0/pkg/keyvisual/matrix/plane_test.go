// Copyright 2022 PingCAP, Inc. Licensed under Apache-2.0.

package matrix

import (
	. "github.com/pingcap/check"
)

var _ = Suite(&testPlaneSuite{})

type testPlaneSuite struct{}
