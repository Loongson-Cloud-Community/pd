---
name: "\U0001F914 Question"
about: I have a question
label: "type/question"
---

## Question

<!--

Thanks for using TiDB Dashboard! Before asking a question, please take a look in the following places:

- GitHub issues
  https://github.com/pingcap/tidb-dashboard/issues?q=is%3Aissue
- Documentation (English)
  https://docs.pingcap.com/tidb/stable/dashboard-intro
- Documentation (Chinese)
  https://docs.pingcap.com/zh/tidb/stable/dashboard-intro
- AskTUG forum (Chinese)
  https://asktug.com/

You might also get a faster response in Slack (English / Chinese):
  https://slack.tidb.io/invite?team=tidb-community&channel=sig-diagnosis&ref=github_issue_create

-->
