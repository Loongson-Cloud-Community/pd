// Copyright 2022 PingCAP, Inc. Licensed under Apache-2.0.

package decorator

import (
	"testing"

	. "github.com/pingcap/check"
)

func TestDecorator(t *testing.T) {
	TestingT(t)
}
