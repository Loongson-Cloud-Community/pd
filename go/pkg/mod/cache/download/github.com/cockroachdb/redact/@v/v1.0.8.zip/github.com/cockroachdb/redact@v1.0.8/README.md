# redact
Utilities to redact Go strings for confidentiality

Godoc link: https://pkg.go.dev/github.com/cockroachdb/redact?tab=doc

