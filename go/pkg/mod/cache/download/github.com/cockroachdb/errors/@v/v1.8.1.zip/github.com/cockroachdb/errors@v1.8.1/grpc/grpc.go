package grpc

//go:generate protoc echoer.proto --go_out=plugins=grpc:.
