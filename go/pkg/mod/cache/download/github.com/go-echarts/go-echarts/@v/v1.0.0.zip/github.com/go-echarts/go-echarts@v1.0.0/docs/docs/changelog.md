---
id: changelog
title: Changelog
sidebar_label: Changelog
---

## 版本日志

### 2019.02.15

* [Add] 新增 ThemeRiver（主题河流图）
* [Add] 新增 Sankey（桑基图）

### 2019.02.14

* [Add] 新增 Graph（关系图）

### 2019.02.11
* [Alpha] 项目正式开源
