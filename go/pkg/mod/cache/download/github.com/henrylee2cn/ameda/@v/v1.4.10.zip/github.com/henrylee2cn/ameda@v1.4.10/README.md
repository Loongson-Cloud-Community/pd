# ameda [![report card](https://goreportcard.com/badge/github.com/henrylee2cn/ameda?style=flat-square)](http://goreportcard.com/report/henrylee2cn/ameda) [![GoDoc](https://img.shields.io/badge/godoc-reference-blue.svg?style=flat-square)](http://godoc.org/github.com/henrylee2cn/ameda)

Powerful toolbox for golang data types.
