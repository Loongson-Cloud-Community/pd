package time

type Time struct {
	S int
}
