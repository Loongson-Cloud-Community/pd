---
name: "🏪 Usability Challenge Program"
about: UCP Season1 Program
title: 'UCP: '
labels: 'challenge-program-2'
---

## UCP Issue

### Description

<!-- Add the issue description here. -->

### Score

<!-- Add the score which the contributor will obtain once this issue is solved. -->

### Mentor

<!-- Add the mentor of this issue. -->

### Recommended Skills

<!-- Add the description about what kind of skills does the contributor should have to solve this issue. -->

### Learning Materials

<!-- Add the description about what kind of materials does the contributor need to learn to solve this issue. -->
