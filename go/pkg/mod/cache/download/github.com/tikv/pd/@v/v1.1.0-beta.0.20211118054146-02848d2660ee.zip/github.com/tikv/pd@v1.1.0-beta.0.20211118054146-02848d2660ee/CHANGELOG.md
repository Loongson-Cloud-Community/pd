# PD Change Log

The details about PD change log can be found in [Release list](https://github.com/tikv/pd/releases).