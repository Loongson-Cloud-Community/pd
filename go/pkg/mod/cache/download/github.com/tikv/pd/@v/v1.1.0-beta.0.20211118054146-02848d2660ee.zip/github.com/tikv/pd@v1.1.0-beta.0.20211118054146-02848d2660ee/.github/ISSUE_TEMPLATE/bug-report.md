---
name: "🐛 Bug Report"
about: Something isn't working as expected
labels: 'type/bug'
---

## Bug Report

<!-- Please answer these questions before submitting your issue. Thanks! -->

### What did you do?

<!-- If possible, provide a recipe for reproducing the error. -->

### What did you expect to see?

### What did you see instead?

### What version of PD are you using (`pd-server -V`)?
