---
name: "\U0001F947 Propose a Challenge Program task with no theme"
about: As a developer, I want to propose a Challenge Program task with no theme.
labels: challenge-program
---

<!-- 
If you want to specify a special theme challenge program task, please add the theme label to the issue(`challenge-program`+`{some-theme-label}`).
Current support theme labels:
 - hptc
 - high-performance
-->

## Description

issue background

## Tasks

- task 1
- task 2
- task 3

## Score

- score number

## Mentor

- @mentor

## Recommended Skills
- skill 1
- skill 2
- skill 3

## Learning Materials(optional)