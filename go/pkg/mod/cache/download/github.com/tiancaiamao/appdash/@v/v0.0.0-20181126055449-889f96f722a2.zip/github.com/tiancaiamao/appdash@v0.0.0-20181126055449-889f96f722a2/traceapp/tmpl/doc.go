// Package tmpl contains template data used by Appdash.
//
// This package needs to be go generated after making changes to template files.
package tmpl

//go:generate vfsgendev -source="github.com/tiancaiamao/appdash/traceapp/tmpl".Data
