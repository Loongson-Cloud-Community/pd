package wire

//go:generate protoc --proto_path=$GOPATH/src/github.com/gogo/protobuf/protobuf/google/protobuf:. --gogo_out=. collector.proto
