// +build !windows

package text

func areANSICodesSupported() bool {
	return true
}
