package strcase

var uppercaseAcronym = map[string]bool{
	"ID": true,
}
